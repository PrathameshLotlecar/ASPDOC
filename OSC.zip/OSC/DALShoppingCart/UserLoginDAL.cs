﻿using BEShoppingCart;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace DALShoppingCart
{
    public class UserLoginDAL
    {

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBONLINESHOPPINGCARTSystemConnectionString"].ConnectionString);
        void connect()
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
        }

        void disconnect()
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }


        public UserLoginResponseBE LoginCredential(UserLoginRequestBE request)
        {
            UserLoginResponseBE response = new UserLoginResponseBE();

            try
            {
                SqlCommand cmd = new SqlCommand("spCHECKLOGIN", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UNAME", request.UserName);
                cmd.Parameters.AddWithValue("@UPASSWORD", request.Password);               
                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;               

                connect(); 
                response.Username = Convert.ToString(cmd.ExecuteScalar());
                response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return response;
        }
    }
}
