﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using BEShoppingCart;

namespace DALShoppingCart
{
    public class UserRegistrationDAL
    {

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBONLINESHOPPINGCARTSystemConnectionString"].ConnectionString);
        void connect()
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
        }

        void disconnect()
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }


        public UserRegistrationResponseBE RegisterUser(UserRegistrationRequestBE request)
        {
            UserRegistrationResponseBE response = new UserRegistrationResponseBE();

            try
            {
                SqlCommand cmd = new SqlCommand("spREGISTERUSERS", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USERNAME", request.UserName);
                cmd.Parameters.AddWithValue("@PASSWORD", request.Password);
                cmd.Parameters.AddWithValue("@DOB", request.DOB);
                cmd.Parameters.AddWithValue("@GENDER", request.Gender);
                cmd.Parameters.AddWithValue("@EMAIL", request.Email);
                cmd.Parameters.AddWithValue("@MOBILE", request.Mobile);
                cmd.Parameters.AddWithValue("@ZIPCODE", request.ZipCode);
                cmd.Parameters.AddWithValue("@ADDRESS", request.Address);
                cmd.Parameters.AddWithValue("@FIRSTNAME", request.FirstName);
                cmd.Parameters.AddWithValue("@LASTNAME", request.LastName);
                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;
                //SqlParameter userNameParameter = cmd.Parameters.Add("@UNAME", SqlDbType.Int);
                //statusParameter.Direction = ParameterDirection.Output;

                connect();
                response.Username = Convert.ToString(cmd.ExecuteScalar());
                response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return response;
        }

    }
}
