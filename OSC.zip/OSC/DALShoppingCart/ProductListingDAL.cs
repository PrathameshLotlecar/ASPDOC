﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using BEShoppingCart;

namespace DALShoppingCart
{
    public class ProductListingDAL
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBONLINESHOPPINGCARTSystemConnectionString"].ConnectionString);
        void connect()
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
        }

        void disconnect()
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }


        public ProductListingResponseBE FetchAllProducts(ProductListingRequestBE request)
        {
            ProductListingResponseBE responseProducts = new ProductListingResponseBE();

            try
            {
                connect();

                SqlCommand cmdFetchProducts = new SqlCommand("spFETCHALLPRODUCTS", conn);
                cmdFetchProducts.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@UNAME", request.UserName);   
                DataTable dtProducts = new DataTable();
                //SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                //statusParameter.Direction = ParameterDirection.Output;

                SqlDataAdapter daAllProducts = new SqlDataAdapter(cmdFetchProducts);
                daAllProducts.Fill(dtProducts);

                responseProducts.ProductList = new List<ProductDetailsBE>();

                foreach(DataRow products in dtProducts.Rows)
                {
                    responseProducts.ProductList.Add(new ProductDetailsBE
                    {
                        PRODUCT_ID = Convert.ToInt32(products[0]),
                        PRODUCT_NAME = products[2].ToString().Trim(),
                        PRODUCT_PRICE = Convert.ToDecimal(products[1]),
                        PRODUCT_AVAILABLE_STOCK = Convert.ToInt32(products[3])
                    });

                }
                
                //responseProducts.Username = Convert.ToString(cmdFetchProducts.ExecuteScalar());
                responseProducts.IsSuccess = true; // TODO pass status
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return responseProducts;
        }

        // TODO pra
        public ProductListingResponseBE FetchRequiredProduct(ProductListingRequestBE request)
        {
            ProductListingResponseBE responseProducts = new ProductListingResponseBE();

            try
            {
                connect();

                SqlCommand cmdFetchProducts = new SqlCommand("spFETCHALLPRODUCTS", conn);
                cmdFetchProducts.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@PRODUCT_ID", request.UserName);   
                DataTable dtProducts = new DataTable();
                //SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                //statusParameter.Direction = ParameterDirection.Output;

                SqlDataAdapter daAllProducts = new SqlDataAdapter(cmdFetchProducts);
                daAllProducts.Fill(dtProducts);

                responseProducts.ProductList = new List<ProductDetailsBE>();

                foreach (DataRow products in dtProducts.Rows)
                {
                    responseProducts.ProductList.Add(new ProductDetailsBE
                    {
                        PRODUCT_ID = Convert.ToInt32(products[0]),
                        PRODUCT_NAME = products[2].ToString().Trim(),
                        PRODUCT_PRICE = Convert.ToDecimal(products[1]),
                        PRODUCT_AVAILABLE_STOCK = Convert.ToInt32(products[3])
                    });

                }

                //responseProducts.Username = Convert.ToString(cmdFetchProducts.ExecuteScalar());
                responseProducts.IsSuccess = true; // TODO pass status
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return responseProducts;
        }  

    }
}
