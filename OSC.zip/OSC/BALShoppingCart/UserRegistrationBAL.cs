﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DALShoppingCart;
using BEShoppingCart;

namespace BALShoppingCart
{
    public class UserRegistrationBAL
    {
        public UserRegistrationResponseBE RegisterUserDetails(UserRegistrationRequestBE request)
        {
            UserRegistrationResponseBE response = null;
            UserRegistrationDAL objUserRegistrationDAL = new UserRegistrationDAL();

            try
            {
                response = objUserRegistrationDAL.RegisterUser(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new UserRegistrationResponseBE();
                }

                response.ErrorCode = 0;
                response.ErrorMessage = ex.Message;
            }

            return response;
        }
        
    }
}
