﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEShoppingCart
{
    public class ProductListingResponseBE : BaseResponse
    {
        public List<ProductDetailsBE> ProductList { get; set; }
    }
}
