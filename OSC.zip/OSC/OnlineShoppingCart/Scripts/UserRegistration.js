﻿$(document).ready(function () {

    $('#txtDOB').datepicker({
        dateFormat: 'dd-mm-yy',
        maxDate: new Date()
    }).val();

    $("#UserRegistrationPage").validate({
        focusInvalid: false,
        focusCleanup: true,
        debug: false,
        onkeyup: false,
        onclick: true,
        onsubmit: true,
        onkeyup: false,
        rules: {
           
            lblFirstName: {
                required: true
            },

            txtUserName: {
                required: true,
                minlength: 5
            },

            txtEmail: {
                required: true,
                email: true
            },

            txtPassword: {
                required: true,
                minlength: 6,
                rangelength: [6, 10]
            }
        },
        messages: {

            lblFirstName: {
                required: "Please enter name"
            },

            txtUserName: {
                required: "Please enter username",
                minlength: "Your user name is too short. Must be at least {0} characters."
            },

            txtEmail: {
                required: "Please enter email address"
            },

            txtPassword: {
                required: "Please enter a password",
                minlength: "Password shoud have atleast 6 characters",
                rangelength: "Password should have atleast {0} characters but not more then {1} characters."
            },
            
        }

        });

});
