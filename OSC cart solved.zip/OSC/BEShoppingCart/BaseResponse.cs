﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEShoppingCart
{
    public class BaseResponse
    {
        public bool issuccess;
        private int errCode;
        private string errorMessage;

        public bool IsSuccess
        {
            get { return issuccess; }
            set { issuccess = value; }
        }

        public int ErrorCode
        {
            get { return errCode; }
            set { errCode = value; }
        }

        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }
    }
}
