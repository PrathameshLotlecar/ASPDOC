﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BALShoppingCart;
using BEShoppingCart;

namespace OnlineShoppingCart
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lbtnNotRegistered_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/UserRegistrationPage.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                UserLoginBAL objLoginBAL = new UserLoginBAL();
                UserLoginRequestBE request = new UserLoginRequestBE();
                request.UserName = txtUserName.Text.Trim();
                request.Password = txtPassword.Text.Trim();

                var response = objLoginBAL.CheckLoginCredential(request);
                if (response.IsSuccess)
                {
                    lblErrMsg.Text = "";
                    Application["userId"] = response.UserId;
                    Session["Name"] = response.Username;
                    Response.Redirect("~/HomePage.aspx");
                }
                else
                {
                    lblErrMsg.Text = "Invalid user credentials...";
                }
            }
            catch (Exception)
            {

                throw;
            } 
        }
    }
}