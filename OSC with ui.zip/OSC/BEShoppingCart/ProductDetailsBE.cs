﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEShoppingCart
{
    public class ProductDetailsBE
    {
        public int PRODUCT_ID {get; set;}
        public string PRODUCT_NAME { get; set; }
        public decimal PRODUCT_PRICE { get; set; }
        public int PRODUCT_AVAILABLE_STOCK { get; set; }

    }  

    /**
     * Request classes
     * **/
    public class UserRegistrationRequestBE
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string ZipCode { get; set; }
        public string Address { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

    }

    public class AddToCartRequestBE
    {
        public int CartItemId { get; set; }
        public int CartProdID { get; set; }
        public int CartUserID { get; set; }
        public int CartQuantity { get; set; }        

    }

    public class CartListingBE
    {
        public int CART_ITEM_ID { get; set; }
        public int PRODUCT_ID { get; set; }
        public int USER_ID { get; set; }
        public int QUANTITY { get; set; }

    }

    public class UserLoginRequestBE
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

    public class ProductListingRequestBE
    {
        public int ProductId { get; set; }
    }    

    
    /**
     * Response classes
     * **/
    public class UserRegistrationResponseBE : BaseResponse
    {
        public string Username { get; set; }
        public int Status { get; set; }

    }

    public class AddToCartResponseBE : BaseResponse
    {
        public string Username { get; set; }
        public int Status { get; set; }

    }

    public class UserLoginResponseBE : BaseResponse
    {
        public string Username { get; set; }
        public int UserId { get; set; }
        public int Status { get; set; }
    }

    public class ProductListingResponseBE : BaseResponse
    {
        public List<ProductDetailsBE> ProductList { get; set; }
    }

    public class CartListingResponseBE : BaseResponse
    {
        public List<CartListingBE> CartList { get; set; }
    }

}
