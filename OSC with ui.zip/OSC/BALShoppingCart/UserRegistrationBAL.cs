﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DALShoppingCart;
using BEShoppingCart;

namespace BALShoppingCart
{
    public class UserRegistrationBAL
    {
        public UserRegistrationResponseBE RegisterUserDetails(UserRegistrationRequestBE request)
        {
            UserRegistrationResponseBE response = null;
            UserRegistrationDAL objUserRegistrationDAL = new UserRegistrationDAL();

            try
            {
                response = objUserRegistrationDAL.RegisterUser(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new UserRegistrationResponseBE();
                }

                response.ErrorCode = 0;
                response.ErrorMessage = ex.Message;
            }

            return response;
        }
        
    }

    public class AddToCartBAL
    {
        public AddToCartResponseBE AddToCart(AddToCartRequestBE request)
        {
            AddToCartResponseBE response = null;
            AddToCartDAL objAddToCartDAL = new AddToCartDAL();

            try
            {
                response = objAddToCartDAL.AddItemToCart(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new AddToCartResponseBE();
                }

                response.ErrorCode = 0;
                response.ErrorMessage = ex.Message;
            }

            return response;
        }

        //public CartListingResponseBE GetAllCartItems(CartListingBE request)
        //{
        //    CartListingResponseBE response = null;
        //    CartListingDAL objAddToCartDAL = new CartListingDAL();

        //    try
        //    {
        //        response = objAddToCartDAL.FetchAllCartItems(request);

        //    }
        //    catch (Exception ex)
        //    {
        //        if (response == null)
        //        {
        //            response = new CartListingResponseBE();
        //        }

        //        response.ErrorCode = 0;
        //        response.ErrorMessage = ex.Message;
        //    }

        //    return response;

        //}

    }


    public class CartListingBAL
    {

        public CartListingResponseBE GetAllCartItems(CartListingBE request)
        {
            CartListingResponseBE response = null;
            CartListingDAL objAddToCartDAL = new CartListingDAL();

            try
            {
                response = objAddToCartDAL.FetchAllCartItems(request);

            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new CartListingResponseBE();
                }

                response.ErrorCode = 0;
                response.ErrorMessage = ex.Message;
            }

            return response;

        }

    }
  


    public class UserLoginBAL
    {

        public UserLoginResponseBE CheckLoginCredential(UserLoginRequestBE request)
        {
            UserLoginResponseBE response = null;
            UserLoginDAL objUserLoginDAL = new UserLoginDAL();

            try
            {
                response = objUserLoginDAL.LoginCredential(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new UserLoginResponseBE();
                }

                response.ErrorCode = 0;
                response.ErrorMessage = ex.Message;
            }

            return response;
        }

    }

    public class ProductListingBAL
    {

        public ProductListingResponseBE GetProducts(ProductListingRequestBE request)
        {
            ProductListingResponseBE response = null;
            ProductListingDAL objProductListingDAL = new ProductListingDAL();

            try
            {
                response = objProductListingDAL.FetchAllProducts(request);

            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new ProductListingResponseBE();
                }

                response.ErrorCode = 0;
                response.ErrorMessage = ex.Message;
            }

            return response;

        }


        public ProductListingResponseBE GetReqProduct(ProductListingRequestBE request)
        {
            ProductListingResponseBE response = null;
            ProductListingDAL objProductListingDAL = new ProductListingDAL();

            try
            {
                response = objProductListingDAL.FetchRequiredProduct(request);

            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new ProductListingResponseBE();
                }

                response.ErrorCode = 0;
                response.ErrorMessage = ex.Message;
            }

            return response;

        }

    }


}
