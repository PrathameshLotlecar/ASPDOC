﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BALShoppingCart;
using BEShoppingCart;

namespace OnlineShoppingCart
{
    public partial class CartListingPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    CartListingBAL objAddToCartBAL = new CartListingBAL();
                    CartListingBE request = new CartListingBE();
                    request.USER_ID = Convert.ToInt32(Application["userId"].ToString());

                    var cartProducts = objAddToCartBAL.GetAllCartItems(request);
                    grdCartList.DataSource = cartProducts.CartList;
                    grdCartList.DataBind();
                }
                catch(Exception ex)
                {

                }
                
            }

        }

        protected void grdCartList_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {

        }
    }
}