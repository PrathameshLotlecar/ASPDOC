﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BALShoppingCart;
using BEShoppingCart;

namespace OnlineShoppingCart
{
    public partial class CheckoutReqProductsPage : System.Web.UI.Page
    {
        int productId;
        ProductListingResponseBE objProductDetails = new ProductListingResponseBE();
        protected void Page_Load(object sender, EventArgs e)
        {            
            if (!IsPostBack)
            {
                try
                {
                    productId = Convert.ToInt32(Session["CartProductId"]);
                    System.Diagnostics.Debug.Write("ProductId **: " + productId.ToString());

                    ProductListingBAL objProductListingBAL = new ProductListingBAL();
                    ProductListingRequestBE request = new ProductListingRequestBE();
                    request.ProductId = Convert.ToInt32(productId);
                    objProductDetails = objProductListingBAL.GetReqProduct(request);
                    //var reqProductDetails = 

                    if (objProductDetails.IsSuccess)
                    {                        
                        lblProductNameValue.Text = objProductDetails.ProductList[0].PRODUCT_NAME.ToString();
                        lblAvailableQtyValue.Text = objProductDetails.ProductList[0].PRODUCT_AVAILABLE_STOCK.ToString();
                        lblPriceValue.Text = objProductDetails.ProductList[0].PRODUCT_PRICE.ToString();
                        //Response.Redirect("~/HomePage.aspx");
                    }
                    else
                    {
                        lblErrMsg.Text = "Could not load details, Please try again.";
                    }
                }
                catch (Exception ex)
                {

                    throw;
                } 
                

            }
        }

        protected void btnAddToCart_Click(object sender, EventArgs e)
        {
            try 
            {
                int itemQty = Convert.ToInt32(txtQtyValue.Text);
                if (itemQty > 0)
                {
                    lblErrMsg.Text = "";
                    try
                    {
                        AddToCartBAL objAddToCartBAL = new AddToCartBAL();
                        AddToCartRequestBE request = new AddToCartRequestBE();
                        request.CartProdID = Convert.ToInt32(Session["CartProductId"]);
                        request.CartUserID = Convert.ToInt32(Application["userId"].ToString());
                        request.CartQuantity = Convert.ToInt32(txtQtyValue.Text.Trim());


                        var response = objAddToCartBAL.AddToCart(request);
                        if (response.IsSuccess)
                        {
                            lblErrMsg.Text = "";
                            Response.Redirect("~/CartListingPage.aspx");
                            //Response.Redirect("~/ProductsListingPage.aspx");
                        }
                        else
                        {
                            lblErrMsg.Text = "Selected product is already present in the cart";
                            //lblErrMsg.Text = "Something went wrong, Please try again.";
                        }
                    }
                    catch (Exception ex)
                    {

                        throw;
                    } 
                    
                }
                else
                {
                    lblErrMsg.Text = "Inorder to add to cart, please select quantity greater then 1";
                }        
            }
            catch(Exception ex)
            {
                lblErrMsg.Text = "Please enter some Quantity";
            }
            
        }

        protected void btnBuy_Click(object sender, EventArgs e)
        {

        }
    }
}