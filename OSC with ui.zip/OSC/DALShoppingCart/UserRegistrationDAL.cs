﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using BEShoppingCart;

namespace DALShoppingCart
{
    public class UserRegistrationDAL
    {

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBONLINESHOPPINGCARTSystemConnectionString"].ConnectionString);
        void connect()
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
        }

        void disconnect()
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }


        public UserRegistrationResponseBE RegisterUser(UserRegistrationRequestBE request)
        {
            UserRegistrationResponseBE response = new UserRegistrationResponseBE();

            try
            {
                SqlCommand cmd = new SqlCommand("spREGISTERUSERS", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USERNAME", request.UserName);
                cmd.Parameters.AddWithValue("@PASSWORD", request.Password);
                cmd.Parameters.AddWithValue("@DOB", request.DOB);
                cmd.Parameters.AddWithValue("@GENDER", request.Gender);
                cmd.Parameters.AddWithValue("@EMAIL", request.Email);
                cmd.Parameters.AddWithValue("@MOBILE", request.Mobile);
                cmd.Parameters.AddWithValue("@ZIPCODE", request.ZipCode);
                cmd.Parameters.AddWithValue("@ADDRESS", request.Address);
                cmd.Parameters.AddWithValue("@FIRSTNAME", request.FirstName);
                cmd.Parameters.AddWithValue("@LASTNAME", request.LastName);
                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;
                //SqlParameter userNameParameter = cmd.Parameters.Add("@UNAME", SqlDbType.Int);
                //statusParameter.Direction = ParameterDirection.Output;

                connect();
                response.Username = Convert.ToString(cmd.ExecuteScalar());
                response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return response;
        }

    }

    public class AddToCartDAL
    {

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBONLINESHOPPINGCARTSystemConnectionString"].ConnectionString);
        void connect()
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
        }

        void disconnect()
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }


        public AddToCartResponseBE AddItemToCart(AddToCartRequestBE request)
        {
            AddToCartResponseBE response = new AddToCartResponseBE();

            try
            {
                SqlCommand cmd = new SqlCommand("spADDTOCART", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PRODUCT_ID", request.CartProdID);
                cmd.Parameters.AddWithValue("@USER_ID", request.CartUserID);
                cmd.Parameters.AddWithValue("@QUANTITY", request.CartQuantity);
                
                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;
                //SqlParameter userNameParameter = cmd.Parameters.Add("@UNAME", SqlDbType.Int);
                //statusParameter.Direction = ParameterDirection.Output;

                connect();
                response.Username = Convert.ToString(cmd.ExecuteScalar());
                //response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
                response.Status = 1;
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return response;
        }
     

    }


    public class CartListingDAL
    {

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBONLINESHOPPINGCARTSystemConnectionString"].ConnectionString);
        void connect()
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
        }

        void disconnect()
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }



        public CartListingResponseBE FetchAllCartItems(CartListingBE request)
        {
            CartListingResponseBE responseProducts = new CartListingResponseBE();
            //CartListingBE requestProducts = new CartListingBE();
            try
            {
                connect();

                SqlCommand cmdFetchCart = new SqlCommand("spFETCHCARTITEMS", conn);
                cmdFetchCart.CommandType = CommandType.StoredProcedure;
                cmdFetchCart.Parameters.AddWithValue("@USER_ID", request.USER_ID);
                DataTable dtProducts = new DataTable();
                //SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                //statusParameter.Direction = ParameterDirection.Output;

                SqlDataAdapter daCartItems = new SqlDataAdapter(cmdFetchCart);
                daCartItems.Fill(dtProducts);

                responseProducts.CartList = new List<CartListingBE>();

                foreach (DataRow products in dtProducts.Rows)
                {
                    responseProducts.CartList.Add(new CartListingBE
                    {
                        CART_ITEM_ID = Convert.ToInt32(products[0]),
                        PRODUCT_ID = Convert.ToInt32(products[1]),
                        USER_ID = Convert.ToInt32(products[2]),
                        QUANTITY = Convert.ToInt32(products[3])
                    });

                }

                //responseProducts.Username = Convert.ToString(cmdFetchProducts.ExecuteScalar());
                responseProducts.IsSuccess = true; // TODO pass status
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return responseProducts;
        }

    }

    public class UserLoginDAL
    {

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBONLINESHOPPINGCARTSystemConnectionString"].ConnectionString);
        void connect()
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
        }

        void disconnect()
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }


        public UserLoginResponseBE LoginCredential(UserLoginRequestBE request)
        {
            UserLoginResponseBE response = new UserLoginResponseBE();

            try
            {
                SqlCommand cmd = new SqlCommand("spCHECKLOGIN", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UNAME", request.UserName);
                cmd.Parameters.AddWithValue("@UPASSWORD", request.Password);
                SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                statusParameter.Direction = ParameterDirection.Output;
                SqlParameter userIdParameter = cmd.Parameters.Add("@USERID", SqlDbType.Int);
                userIdParameter.Direction = ParameterDirection.Output;
                

                connect();
                cmd.ExecuteReader();
                //response.Username = Convert.ToString(cmd.ExecuteScalar());
                response.Username = request.UserName;
                response.Status = Convert.ToInt32(cmd.Parameters["@STATUS"].Value);
                response.UserId = Convert.ToInt32(cmd.Parameters["@USERID"].Value);

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return response;
        }
    }


    public class ProductListingDAL
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBONLINESHOPPINGCARTSystemConnectionString"].ConnectionString);
        void connect()
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
        }

        void disconnect()
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }


        public ProductListingResponseBE FetchAllProducts(ProductListingRequestBE request)
        {
            ProductListingResponseBE responseProducts = new ProductListingResponseBE();

            try
            {
                connect();

                SqlCommand cmdFetchProducts = new SqlCommand("spFETCHALLPRODUCTS", conn);
                cmdFetchProducts.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@UNAME", request.UserName);   
                DataTable dtProducts = new DataTable();
                //SqlParameter statusParameter = cmd.Parameters.Add("@STATUS", SqlDbType.Int);
                //statusParameter.Direction = ParameterDirection.Output;

                SqlDataAdapter daAllProducts = new SqlDataAdapter(cmdFetchProducts);
                daAllProducts.Fill(dtProducts);

                responseProducts.ProductList = new List<ProductDetailsBE>();

                foreach (DataRow products in dtProducts.Rows)
                {
                    responseProducts.ProductList.Add(new ProductDetailsBE
                    {
                        PRODUCT_ID = Convert.ToInt32(products[0]),
                        PRODUCT_NAME = products[2].ToString().Trim(),
                        PRODUCT_PRICE = Convert.ToDecimal(products[1]),
                        PRODUCT_AVAILABLE_STOCK = Convert.ToInt32(products[3])
                    });

                }

                //responseProducts.Username = Convert.ToString(cmdFetchProducts.ExecuteScalar());
                responseProducts.IsSuccess = true; // TODO pass status
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return responseProducts;
        }

        // TODO pra
        public ProductListingResponseBE FetchRequiredProduct(ProductListingRequestBE request)
        {
            ProductListingResponseBE responseProducts = new ProductListingResponseBE();

            try
            {
                connect();

                SqlCommand cmdFetchProduct = new SqlCommand("[spFETCHREQPRODUCT]", conn);
                cmdFetchProduct.CommandType = CommandType.StoredProcedure;
                cmdFetchProduct.Parameters.AddWithValue("@PRODUCT_ID", request.ProductId);
                DataTable dtProducts = new DataTable();                

                SqlDataAdapter daReqProduct = new SqlDataAdapter(cmdFetchProduct);
                daReqProduct.Fill(dtProducts);

                responseProducts.ProductList = new List<ProductDetailsBE>();

                foreach (DataRow products in dtProducts.Rows)
                {
                    responseProducts.ProductList.Add(new ProductDetailsBE
                    {
                        PRODUCT_ID = Convert.ToInt32(products[0]),
                        PRODUCT_NAME = products[2].ToString().Trim(),
                        PRODUCT_PRICE = Convert.ToDecimal(products[1]),
                        PRODUCT_AVAILABLE_STOCK = Convert.ToInt32(products[3])
                    });

                }

                //responseProducts.Username = Convert.ToString(cmdFetchProducts.ExecuteScalar());
                responseProducts.IsSuccess = true; // TODO pass status
            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                disconnect();
            }

            return responseProducts;
        }

    }
}
