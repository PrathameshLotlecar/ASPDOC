﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BALShoppingCart;
using BEShoppingCart;

namespace OnlineShoppingCart
{
    public partial class CheckoutReqProductsPage : System.Web.UI.Page
    {
        int productId;

        protected void Page_Load(object sender, EventArgs e)
        {            
            if (!IsPostBack)
            {
                productId = Convert.ToInt32(Session["CartProductId"]);
                System.Diagnostics.Debug.Write("ProductId **: " + productId.ToString());

                ProductListingBAL objProductListingBAL = new ProductListingBAL();
                ProductListingRequestBE request = new ProductListingRequestBE();

                var allProducts = objProductListingBAL.GetProducts(request);

            }
        }
    }
}