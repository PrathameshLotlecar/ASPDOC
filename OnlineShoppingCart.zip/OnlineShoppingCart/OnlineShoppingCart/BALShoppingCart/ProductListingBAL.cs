﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BEShoppingCart;
using DALShoppingCart;

namespace BALShoppingCart
{
    public class ProductListingBAL
    {

        public ProductListingResponseBE GetProducts(ProductListingRequestBE request)
        {
            ProductListingResponseBE response = null;
            ProductListingDAL objProductListingDAL = new ProductListingDAL();

            try
            {
                response = objProductListingDAL.FetchAllProducts(request);
                
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new ProductListingResponseBE();
                }

                response.ErrorCode = 0;
                response.ErrorMessage = ex.Message;
            }

            return response;

        }
    }
}
