﻿using BEShoppingCart;
using DALShoppingCart;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BALShoppingCart
{
    public class UserLoginBAL
    {

        public UserLoginResponseBE CheckLoginCredential(UserLoginRequestBE request)
        {
            UserLoginResponseBE response = null;
            UserLoginDAL objUserLoginDAL = new UserLoginDAL();

            try
            {
                response = objUserLoginDAL.LoginCredential(request);
                response.IsSuccess = (response.Status >= 1);
            }
            catch (Exception ex)
            {
                if (response == null)
                {
                    response = new UserLoginResponseBE();
                }

                response.ErrorCode = 0;
                response.ErrorMessage = ex.Message;
            }

            return response;
        }

    }

    
}
