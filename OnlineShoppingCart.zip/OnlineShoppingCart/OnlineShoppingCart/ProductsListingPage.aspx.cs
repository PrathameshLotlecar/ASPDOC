﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BEShoppingCart;
using BALShoppingCart;

namespace OnlineShoppingCart
{
    public partial class ProductsListingPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                ProductListingBAL objProductListingBAL = new ProductListingBAL();
                ProductListingRequestBE request = new ProductListingRequestBE();
                
                var allProducts = objProductListingBAL.GetProducts(request);
                grdProducts.DataSource = allProducts.ProductList;
                grdProducts.DataBind();
            }
        }

        protected void grdProducts_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {               
            int productId = Convert.ToInt32(grdProducts.DataKeys[e.NewSelectedIndex].Value);
            // TODO SYS OUT System.Diagnostics.Debug.Write("ProductId: " + productId.ToString());
            Session["CartProductId"] = productId.ToString();
            Response.Redirect("~/CheckoutReqProductsPage.aspx");


        }
      


    }
}