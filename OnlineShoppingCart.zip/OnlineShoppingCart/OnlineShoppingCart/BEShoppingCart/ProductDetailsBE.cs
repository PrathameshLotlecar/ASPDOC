﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEShoppingCart
{
    public class ProductDetailsBE
    {
        public int PRODUCT_ID {get; set;}
        public string PRODUCT_NAME { get; set; }
        public decimal PRODUCT_PRICE { get; set; }
        public int PRODUCT_AVAILABLE_STOCK { get; set; }

    }
}
