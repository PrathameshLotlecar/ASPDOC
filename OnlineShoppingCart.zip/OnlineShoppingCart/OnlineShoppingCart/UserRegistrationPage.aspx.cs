﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BALShoppingCart;
using BEShoppingCart;

namespace OnlineShoppingCart
{
    public partial class UserRegistrationPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ddlGender.Text = "Please select gender";
                ddlGender.Items.Add("Male");
                ddlGender.Items.Add("Female");                
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                UserRegistrationBAL objRegistrationBAL = new UserRegistrationBAL();
                UserRegistrationRequestBE request = new UserRegistrationRequestBE();
                request.UserName = txtUserName.Text.Trim();
                request.Password = txtPassword.Text.Trim();
                request.DOB = Convert.ToDateTime(txtDOB.Text);
                //request.DOB = Convert.ToDateTime("16-10-1994");
                request.Gender = ddlGender.Text.Trim();
                request.Email = txtEmail.Text.Trim();
                request.Mobile = txtMobile.Text.Trim();
                request.ZipCode = txtZipcode.Text.Trim();
                request.Address = txtAddress.Text.Trim();
                request.FirstName = txtFirstName.Text.Trim();
                request.LastName = txtLastName.Text.Trim();

                var response = objRegistrationBAL.RegisterUserDetails(request);
                if (response.IsSuccess)
                {
                    lblErrMsg.Text = "";                   
                    Response.Redirect("~/HomePage.aspx");
                }
                else
                {
                    lblErrMsg.Text = "Error while inserting user, Please try again.";
                }
            }
            catch (Exception ex)
            {

                throw;
            } 

        }
    }
}